const express = require("express");
const User = require("../model/UserModel");
const { protect } = require("../middleware/auth");

const {
	registerUser,
	login,
	 
	removeFlightByName,
	getBookingsByFlightNameAndDate,
	getProfile,
	
	 
	createflight,
	bookTicket,
	getFlightsByDate
	 
	 
} = require("../controller/Auth/AuthController");

const router = express.Router();

router.post("/register", registerUser);
  
 

router.get("/get-user-details/:user_id", protect, getProfile);
router.get("/getFlightsByDate/:date", getFlightsByDate);
router.get("/getBookingsByFlightNameAndDate/:flightname/:bookingdate", getBookingsByFlightNameAndDate);


router.post("/booktickets",protect,bookTicket);
 
 
router.delete("/removeFlightByName",protect,removeFlightByName);
router.post("/createFlight",protect, createflight)
router.post("/login", login);
 
 
 

module.exports = router;
