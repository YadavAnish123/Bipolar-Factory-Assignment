const mongoose = require("mongoose");
const { Schema } = mongoose;

// Define the schema
const flightSchema = new Schema({

  flightname: {
    type: String,
    required: true,
  },
  bookingdate: {
    type: Date,  
    required: true,
  },
  avalibleseat: {
    type: Number,
    min: 0 ,
    default:60 
    
  }
   
});

// Create and export the model
const flightModel = mongoose.model("flight", flightSchema);
module.exports = flightModel;
