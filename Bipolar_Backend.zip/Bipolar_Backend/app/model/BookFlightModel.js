const mongoose = require("mongoose");
const { Schema } = mongoose;

// Define the schema
const BookFlightSchema = new Schema({
    createdby: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    flight:{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'flight',
        required: true
    },
    totalBooked:{
     type:Number,
      require:true
    }
   
   
});

// Create and export the model
const BookflightModel = mongoose.model("BookflightModel", BookFlightSchema);
module.exports =  BookflightModel;
