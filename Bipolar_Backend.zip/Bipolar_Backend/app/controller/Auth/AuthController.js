const User = require("../../model/UserModel");
//const Remind=require("../../model/ReminderMode")
const axios = require('axios');
const bcrypt = require("bcryptjs");
const { ObjectId } = require("mongodb");
const flightModel = require('../../model/FlightModel');

 
 

const asynchandler = require("express-async-handler");
const generateToken = require("../../utils/generateToken");
const BookflightModel = require("../../model/BookFlightModel");
const dotenv = require("dotenv").config();
 
const registerUser = asynchandler(async (req, res) => {
	try {
		console.log("userRegister is calling")
		const { full_name, email,  password} = req.body;
		const userExist = await User.findOne({ email});
		if (userExist) {
			return res.status(409).json({ status: false, message: "Email already in use" });
		}
		const user = await User.create({
			full_name,
			email,
			password
			 
		});

		if (user) {
			const Getdata = await User.findOne({ _id: user._id })
			res.status(201).json({
				status: true,
				message: "register successfully",
				data: Getdata,
				token: generateToken(user._id),
			});
		} else {
			res.status(404).json({
				status: false,
				message: "Error Occured",
			});
		}
	} catch (e) {
		res.status(500).json({
			status: false,
			message: e.message,
		});
	}
});

 

 

 

 

 

const getProfile = asynchandler(async (req, res) => {
	try {
		const { user_id } = req.params;
		console.log(user_id)

		//const sssd = await User.findOne({ _id: user_id }) 
		const BookedData= await BookflightModel.find({ "createdby":user_id}).populate("flight")  // Populate flight details
		.populate('createdby')  // Populate user details
		.exec();

		res.status(200).json({
			status: true,
			message: "data saved",
			data: BookedData,
			 
		});
	} catch (e) {
		res.status(500).json({
			status: false,
			message: "server error",
		});
	}
});

const login = asynchandler(async (req, res) => {
	try {
		console.log("log is calling")
		const { email, password} = req.body;
		console.log(email,password)
			const comp = await User.findOne({ email });
			const d=await BookflightModel.find({ "BookedData.createdby":{_id:comp._id}})
			if (comp && (await comp.matchPassword(password))) {
				console.log(1)
				 
				res.status(201).json({
					status: true,
					message: "logged in",
					data: comp,
					tickets:d,
                    
					 
					token: generateToken(comp._id),
				});
			} else {
				res.status(400).json({
					status: false,
					message: "invalid email or password",
				});
			}
	} catch (e) {
		res.status(500).json({
			status: false,
			message: e.message,
		});
	}
});
 

const createflight = asynchandler(async (req, res) => {
	try {
	  console.log("Create flight is calling");   
	  const {flightname, bookingdate,avalibleseat
	  } = req.body;	  
		const newflight = new flightModel({
			flightname,
			bookingdate,
			avalibleseat:avalibleseat
		  });	   
		  await newflight.save();	   
	  const tickets = await flightModel.find();   
	  res.status(200).json({
		status: true,
		message: tickets,
	  });
	} catch (e) {
	  res.status(500).json({
		status: false,
		message: e.message,
	  });
	}
  });

  const removeFlightByName = asynchandler(async (req, res) => {
	try {
	  console.log("Removing flight by name");
  
	   
	  const { flightname } = req.body;
  
	   
	  if (!flightname) {
		return res.status(400).json({
		  status: false,
		  message: 'Flight name is required',
		});
	  }
  
	   
	  const result = await flightModel.findOneAndDelete({ flightname });
  
	  if (!result) {
		return res.status(404).json({
		  status: false,
		  message: 'Flight not found',
		});
	  }
  
	   
	  res.status(200).json({
		status: true,
		message: 'Flight removed successfully',
	  });
	} catch (e) {
	  res.status(500).json({
		status: false,
		message: e.message,
	  });
	}
  });
  

  const getFlightsByDate = asynchandler(async (req, res) => {
  try {
    console.log("Fetching flights for the specified date");

     
    const { date } = req.params;

	console.log(date)

     
    if (!date) {
      return res.status(400).json({
        status: false,
        message: 'Date is required',
      });
    }

    
    const flights = await flightModel.find({ bookingdate: date });

    if (flights.length === 0) {
      return res.status(404).json({
        status: false,
        message: 'No flights found for the specified date',
      });
    }

     
    res.status(200).json({
      status: true,
      message: flights,
    });
  } catch (e) {
    res.status(500).json({
      status: false,
      message: e.message,
    });
  }
});

  const bookTicket = asynchandler(async (req, res) => {
	try {
	  console.log("Booking ticket is calling");
  
	   
	  const {flight,totalBooked,createdby } = req.body;
	   
  
	  
    
		const newTicket = new BookflightModel({
			createdby:createdby,
			flight:flight,
			totalBooked: totalBooked, 
		 
		})   
  
	 
		await newTicket.save();


		const updateflight=await flightModel.findById(flight);
		let avalibleseat=updateflight.avalibleseat;
		avalibleseat-=totalBooked
		
		 
    await flightModel.findByIdAndUpdate(flight, { avalibleseat: avalibleseat });
  
	   
	  const data = await BookflightModel.find({"createdby":createdby});
  
	  
	  res.status(200).json({
		status: true,
		message: data,
	  });
	} catch (e) {
	  res.status(500).json({
		status: false,
		message: e.message,
	  });
	}
  });

  const getUserTickets = asynchandler(async (req, res) => {
	try {
	  console.log("Fetching user tickets");
  
	   
	  const { userId } = req.params;
  
	   
	  if (!userId) {
		return res.status(400).json({
		  status: false,
		  message: 'User ID is required',
		});
	  }
  
	   
	  const tickets = await BookflightModel.find({ createdby: userId })
		.populate('flight')  
		.populate('createdby')   
		.exec();
  
	  
	  res.status(200).json({
		status: true,
		message: 'Tickets fetched successfully',
		tickets,
	  });
	} catch (e) {
	  res.status(500).json({
		status: false,
		message: e.message,
	  });
	}
  });
  
  const getBookingsByFlightNameAndDate = asynchandler(async (req, res) => {
  try {
    console.log("Fetching bookings by flight name and date");

     
    const { flightname, bookingdate } = req.params; 
    if (!flightname || !bookingdate) {
      return res.status(400).json({
        status: false,
        message: 'Flight name and booking date are required',
      });
    }

     
    const flights = await flightModel.find({
      flightname: flightname,
      bookingdate: bookingdate
    });

    if (flights.length === 0) {
      return res.status(404).json({
        status: false,
        message: 'No flights found for the specified name and date',
      });
    }

    
    const flightIds = flights.map(flight => flight._id);

    
    const bookings = await BookflightModel.find({
      flight: { $in: flightIds }
    }).populate('createdby')  
      .populate('flight');  

    if (bookings.length === 0) {
      return res.status(404).json({
        status: false,
        message: 'No bookings found for the specified flight name and date',
      });
    }

    
    res.status(200).json({
      status: true,
      message: bookings,
    });
  } catch (e) {
    res.status(500).json({
      status: false,
      message: e.message,
    });
  }
});
 
 

 
module.exports = {
	registerUser,
	login,
	 
	removeFlightByName,
	createflight,
	getFlightsByDate ,
	bookTicket,
	getUserTickets,
	getProfile,
	getBookingsByFlightNameAndDate,
	 
	
	 
};
